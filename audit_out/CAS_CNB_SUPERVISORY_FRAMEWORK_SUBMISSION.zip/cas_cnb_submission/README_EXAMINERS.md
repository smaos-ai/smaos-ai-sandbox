# 🏛️ ČAS / ČNB / ÚOOÚ Supervisory Inspection Guide
**Offline Verification of Autonomous AI Agents under DORA Art. 17 & EU AI Act Art. 12/14**

This submission package provides regulatory supervisors with a 100% offline, zero-cloud-egress verification toolkit to inspect autonomous agent runtime truth, tamper-evident audit trails, and GDPR Article 17 PII redaction.

---

## 🚀 Quick-Start for Examiners (Zero Dependencies, Zero Network)

1. **Open the Supervisory Terminal**:
   - Double-click `verifier.html` in this folder (or open in Chrome, Firefox, Safari, or Edge via `file://`).
   - Notice: **0 bytes of network traffic** are sent. No external JavaScript libraries, analytics, or servers are contacted.

2. **Verify a BBS+ PII-Redacted Record (GDPR Art. 17 vs. EU AI Act Art. 12)**:
   - Drag and drop `sample_evidence/bbs_derived_proof.json` onto the dropzone in `verifier.html`.
   - Observe: The customer IBAN is verified as `[REDACTED_CONFIDENTIAL_PII]`, while the cryptographic signature remains **VALID**.

3. **Verify an IETF SCITT Sealed Statement (DORA Art. 17)**:
   - Drag and drop `sample_evidence/trust_passport.cose.json` onto the dropzone.
   - Observe: The RFC 8785 (JCS) canonical pre-image hash, Key ID (`kid`), and SCITT signature are displayed and validated.

4. **Inspect the EBA Register of Information (DORA Art. 28)**:
   - Unzip or inspect `DORA_Register_DPM40_EBA_ITS_2024_2956.zip`.
   - Contains all 15 relational tables (`RT.01.01` to `RT.99.01`) compliant with **EBA DPM 4.0 / ITS 2024/2956**, pre-populated with ISO 17442 LEI MOD 97-10 verified identifiers.

5. **Examine the Full Submission Dossier**:
   - Read `COVER_LETTER_CAS_CNB_SUPERVISORY_FRAMEWORK.md` and `REGULATORY_SANDBOX_SUBMISSION_DOSSIER.md` for complete technical, legal, and operational specifications.

---

*SovereignNexus s.r.o. | Prague, Czech Republic | Contact: andrejlo123@gmail.com*
